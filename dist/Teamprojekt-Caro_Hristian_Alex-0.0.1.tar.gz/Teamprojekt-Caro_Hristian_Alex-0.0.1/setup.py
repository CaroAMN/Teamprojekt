import setuptools


setuptools.setup(
    name="Teamprojekt-Caro_Hristian_Alex", 
    version="0.0.1",
    author="Caro_Hristian_Alex",
    author_email="author@example.com",
    description="Erster Versuch eines packages",
    url="https://github.com/CaroAMN/Teamprojekt",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)